import random
import numpy as np
import matplotlib.pyplot as plt
from expression_tree import *
from node import *
from constants import *
import copy
from sklearn.metrics import mean_squared_error

class gplearn:
    def __init__(self, dimensions=2, max_depth=5, population_size=200, generations=25, mutation_rate=0.1):
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.population = []
        self.max_depth = max_depth
        self.dimensions = dimensions

    def __initialize_population(self):
        for _ in range(self.population_size):
            tree = ExpressionTree.create_random_tree(rnd.randint(0, self.max_depth), self.dimensions)
            self.population.append(tree)

    def __evaluate_fitness(self, x, y, z=None):
        fitness_scores = []
        for tree in self.population:
            predicted = tree.evaluate({'x': x, 'y': y})
            if type(predicted) == int:
                predicted = np.full(x.shape, predicted)
            try:
                fitness = -mean_squared_error(y if z is None else z, predicted)
            except:
                fitness = float('-inf')
            fitness_scores.append(fitness)
        return fitness_scores

    def __selection(self, fitness_scores):
        # roulette whill
        # total_fitness = sum(fitness_scores)
        # probabilities = [(1 - (fitness / total_fitness)) for fitness in fitness_scores]
        # selected_parents = random.choices(self.population, weights=probabilities, k=int(self.population_size / 2))
        # return selected_parents
        # Select parents based on the highest fitness (elitism)
        sorted_indices = sorted(range(len(fitness_scores)), key=lambda k: fitness_scores[k], reverse=True)
        selected_parents = [self.population[i] for i in sorted_indices[:self.population_size]]
        return selected_parents
        
    def __crossover(self, parent1, parent2):
        crossover_point1 = random.choice(parent1.get_all_nodes())
        crossover_point2 = random.choice(parent2.get_all_nodes())

        child1 = copy.deepcopy(parent1)
        child2 = copy.deepcopy(parent2)

        crossover_point1.replace_subtree(child2)
        crossover_point2.replace_subtree(child1)

        return child1, child2

    def __mutation(self, tree):
        mutation_point = random.choice(tree.get_all_nodes())
        new_subtree = ExpressionTree.create_random_tree(random.randint(1, self.max_depth))
        mutation_point.replace_subtree(new_subtree.root)

    def fit(self, x, y, z=None):
        self.__initialize_population()
        rows = self.generations // 5
        
        if z is None:
            figure, axis = plt.subplots(rows, 5)
        else:
            figure, axis = plt.subplots(rows, 5, subplot_kw={'projection': '3d'})
        
        previous_avg_mse = float('inf')
        stillness_counter = 1
        
        for i in range(rows):    
            for j in range(5):
                fitness_scores = self.__evaluate_fitness(x, y, z)                   
                parents = self.__selection(fitness_scores)
                current_avg_mse = np.average(fitness_scores)
                if (current_avg_mse < previous_avg_mse and stillness_counter <= 5):
                    stillness_counter += 1
                else:
                    stillness_counter = 1

                offspring = []
                for k in range(1, len(parents)):
                    parent1 = parents[k]
                    parent2 = parents[k - 1]
                    child1, child2 = self.__crossover(parent1, parent2)
                    offspring.extend([child1, child2])

                for tree in offspring:
                    _rand = rnd.random()
                    if _rand < self.mutation_rate * stillness_counter:
                        self.__mutation(tree)

                self.population = offspring

                # Best individual in the current generation
                best_idx = np.argmax(fitness_scores)
                best_tree = self.population[best_idx]
                best_fitness = fitness_scores[best_idx]
                
                predicted = best_tree.evaluate({'x': x, 'y': y})
                if type(predicted) == int:
                    predicted = np.full(x.shape, predicted)
                    
                if z is None:
                    axis[i, j].plot(x, y, 'lightblue')
                    axis[i, j].plot(x, predicted, 'red')
                else:
                    axis[i, j].plot3D(x, y, z, 'lightblue')
                    axis[i, j].plot3D(x, y, predicted, 'red')
                
                generation = i * rows + j + 1
                axis[i, j].set_title(f"{generation}")
                print(f"Generation {generation}, Best Fitness: {best_fitness}")
                
                if best_fitness == 0.0:
                    return best_tree
            
        figure.show()
        # Return the best individual from the final generation
        best_idx = np.argmax(fitness_scores)
        return self.population[best_idx]
    