import random as rnd
from node import *
from constants import *

class ExpressionTree:
    def __init__(self, root: Node=None):
        self.root = root
    
    def create_random_tree(depth, dimensions=2):
        if depth == 0:
            return ExpressionTree(Node.create_random_node(Type.Operand))
        else:
            root = Node.create_random_node(Type.Operator)
            ExpressionTree.__create_random_tree(depth - 1, root, dimensions)
            return ExpressionTree(root)
    
    def __create_random_tree(depth, parent: Node=None, dimensions=2):
        op_count = operands_count(parent.data)
        if (depth == 0):
            parent.right = Node.create_random_node(Type.Operand, op_count == 1, parent.data == '/', parent.data == '^', dimensions)
            if (operands_count(parent.data) != 1):
                parent.left = Node.create_random_node(Type.Operand, True)
        else:                    
            type = Type.Operator if rnd.random() < 0.5 else Type.Operand
            parent.right = Node.create_random_node(type, op_count == 1, parent.data == '/', parent.data == '^', dimensions)
            
            if (op_count != 1):
                type = Type.Operator if rnd.random() < 0.5 else Type.Operand
                parent.left = Node.create_random_node(type, True, dimensions=dimensions)
            
            if (parent.right.type == Type.Operator):
                ExpressionTree.__create_random_tree(depth - 1, parent.right, dimensions)
                
            if (operands_count(parent.data) != 1 and parent.left.type == Type.Operator):
                ExpressionTree.__create_random_tree(depth - 1, parent.left, dimensions)
            
    def evaluate(self, dic: dict, node: Node=None):
        if node is None:
            node = self.root

        if (type(node.data) == int):
            return node.data
        
        if (node.data in dic.keys()):
            return dic[node.data]

        if (node.left):
            left_result = self.evaluate(dic, node.left)
        
        if (node.right):
            right_result = self.evaluate(dic, node.right)

        if (operands_count(node.data) == 1):
            return operators[node.data](right_result)
        else:
            return operators[node.data](left_result, right_result)

    def inorder_traversal(self):
        return self.__inorder_traversal(self.root)
            
    def __inorder_traversal(self, node: Node=None):
        if node is None:
            return ''
        
        if node is not None:
            left = self.__inorder_traversal(node.left)
            right = self.__inorder_traversal(node.right)
            return '(' + left + ' ' + str(node.data) + ' ' + right + ')'


    def get_all_nodes(self):
        return self.__get_all_nodes(self.root)

    def __get_all_nodes(self, node):
        if node is None:
            return []
        return [node] + self.__get_all_nodes(node.left) + self.__get_all_nodes(node.right)
    