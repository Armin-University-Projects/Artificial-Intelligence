import numpy as np
from enum import Enum

operators = {'+': np.add, '-': np.subtract, '*': np.multiply, '/': np.divide, '^': np.power, 'sin': np.sin, 'cos': np.cos}
terminals = ['x', 'y']
min_operand = -5
max_operand = 5

class Type(Enum):
    Operator = 0
    Operand = 1
    
def operands_count(operator):
    if operator =='sin':
        return 1
    elif operator == 'cos':
        return 1
    else:
        return 2
    