import random as rnd
from constants import *

class Node:
    def __init__(self, type: Type, data):
        self.parent = None
        self.left = None
        self.right = None
        self.type = type
        self.data = data
        
    def create_random_node(type: Type, is_terminal: bool=False, non_zero: bool=False, non_negative: bool=False, dimensions: int=2):
        if type == Type.Operand:
            if is_terminal:
                return Node(type, terminals[rnd.randint(0, dimensions - 2)])
            else:
                data = rnd.randint(min_operand, max_operand)
                if (data <= 0 and non_negative):
                    data = rnd.randint(1, max_operand)
                elif (data == 0 and non_zero):
                    data = rnd.randint(min_operand, -1) if rnd.randint(1, 2) == 1 else rnd.randint(1, max_operand)
        else:
            data = rnd.choice(list(operators.keys()))
        return Node(type, data)
        
    def replace_subtree(self, new_subtree_root):
        if self.parent is not None:
            if self.parent.left == self:
                self.parent.left = new_subtree_root
            elif self.parent.right == self:
                self.parent.right = new_subtree_root

        if new_subtree_root is not None:
            new_subtree_root.parent = self.parent

        self.parent = None