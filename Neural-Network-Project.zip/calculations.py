import numpy as np
 
def accuracy(test, prediction):
    return np.sum(test == prediction) / len(test)

def sin(x):
    return np.sin(x)

def sink(x):
    if x.all() == 0:
        return 1
    return np.sin(np.pi * x) / (np.pi * x)

def tan(x):
    return np.tan(x)

def stairs(x):
    return np.trunc(x)

def gloomy_function(x):
    return -2 * np.sin(x) - 0.5 * x ** 2 - 3 * np.sin(3 * x) - 2 * np.sin(5 * x) - np.sin(10 * x)


def psnr(original, denoised):
    mse = np.mean((original - denoised) ** 2)
    max_pixel_value = 1.0  # Assuming pixel values are normalized between 0 and 1
    psnr_value = 10 * np.log10((max_pixel_value ** 2) / mse)
    return psnr_value