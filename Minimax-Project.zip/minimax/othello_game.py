class OthelloGame:
    def __init__(self, starting_player = 'B'):
        self.board = [['.' for _ in range(8)] for _ in range(8)]
        self.board[3][3] = 'W'
        self.board[4][4] = 'W'
        self.board[3][4] = 'B'
        self.board[4][3] = 'B'
        self.current_player = starting_player
        self.move_count = 0

    def display_board(self):
        print(f'\nMove {self.move_count}\n')
        print(' ', end=' ')
        for j in range(8):
            print(f'{j}', end = ' ')
        print()
        
        for i in range(8):
            print(f"{i} {' '.join(self.board[i])}")
        print()
        
    def outflanks(self, row, col):
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (-1, -1), (-1, 1), (1, -1)]
        for dr, dc in directions:
            r, c = row + dr, col + dc
            
            if 0 > r or r >= 8 or 0 > c or c >= 8 or self.board[r][c] != self.get_opponent():
                continue
            
            r, c = r + dr, c + dc
            while 0 <= r < 8 and 0 <= c < 8 and self.board[r][c] == self.get_opponent():
                r += dr
                c += dc
            
            if 0 <= r < 8 and 0 <= c < 8 and self.board[r][c] == self.current_player:
                return True
            
        return False
        
    def is_valid_move(self, row, col):
        if 0 <= row < 8 and 0 <= col < 8 and self.board[row][col] == '.' and self.outflanks(row, col):
            return True
        return False

    def flip_pieces(self, row, col):
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (-1, -1), (-1, 1), (1, -1)]
        for dr, dc in directions:
            r, c = row + dr, col + dc
            pieces_to_flip = []
            while 0 <= r < 8 and 0 <= c < 8 and self.board[r][c] == self.get_opponent():
                pieces_to_flip.append((r, c))
                r += dr
                c += dc
            if 0 <= r < 8 and 0 <= c < 8 and self.board[r][c] == self.current_player:
                for piece in pieces_to_flip:
                    self.board[piece[0]][piece[1]] = self.current_player

    def get_opponent(self):
        return 'W' if self.current_player == 'B' else 'B'

    def make_move(self, row, col):
        if self.is_valid_move(row, col):
            self.board[row][col] = self.current_player
            self.flip_pieces(row, col)
            self.current_player = self.get_opponent()
            self.move_count += 1
            return True
        return False

    def get_count(self):
        return sum(row.count(self.current_player) for row in self.board)

    def get_winner(self):
        count_b = sum(row.count('B') for row in self.board)
        count_w = sum(row.count('W') for row in self.board)

        if count_b > count_w:
            return 'B'
        elif count_w > count_b:
            return 'W'
        else:
            return 'Draw'

    def is_game_over(self):
        if all('.' not in row for row in self.board):
            return True
        
        if self.can_make_move():
            return False
        
        self.current_player = self.get_opponent()
        return not self.can_make_move()
    
    def can_make_move(self):
        for i in range(8):
            for j in range(8):
                if self.is_valid_move(i, j):
                    return True
        return False
    
    def copy(self):
        game_copy = OthelloGame()
        game_copy.board = [row.copy() for row in self.board]
        game_copy.current_player = self.current_player
        game_copy.move_count = self.move_count
        return game_copy
