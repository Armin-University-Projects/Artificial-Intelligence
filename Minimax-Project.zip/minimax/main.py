from othello_game import *
from minimax import *

othello_game = OthelloGame()

while not othello_game.is_game_over():
    othello_game.display_board()
    if othello_game.current_player == 'B':
        print("Black's turn")
        if not othello_game.can_make_move():
            print("No valid move!")
            othello_game.current_player = othello_game.get_opponent()
            continue
        search_depth = get_depth(othello_game, othello_game.move_count)
        _, best_move = minimax(othello_game, search_depth, True)
        print(f'Move: ({best_move[0]}, {best_move[1]}) \t Depth searched: {search_depth}')
        othello_game.make_move(*best_move)
    else:
        print("White's turn")
        if not othello_game.can_make_move():
            print("No valid move!")
            othello_game.current_player = othello_game.get_opponent()
            continue
        
        while True:
            move = input("Move: ")
            row, col = tuple(int(m) for m in move.split())
            if othello_game.is_valid_move(row, col):
                break
            else:
                print("Invalid Move! Try again...")
        print(f'Move: ({row}, {col})')
        othello_game.make_move(row, col)

othello_game.display_board()
print("Winner: " + othello_game.get_winner())
