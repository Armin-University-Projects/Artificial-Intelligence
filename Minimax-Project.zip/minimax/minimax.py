from othello_game import *

def minimax(game: OthelloGame, depth, maximizing_player):
    tmp_player = game.current_player
    if depth == 0 or game.is_game_over():
        return game.get_count(), (None, None)
    
    if tmp_player != game.current_player:
        return minimax(game, depth - 1, not maximizing_player)

    if maximizing_player:
        max_eval = float('-inf')
        for i in range(8):
            for j in range(8):
                if game.is_valid_move(i, j):
                    game_copy = game.copy()
                    game_copy.make_move(i, j)
                    eval, _ = minimax(game_copy, depth - 1, False)
                    if eval > max_eval:
                        max_eval = eval
                        best_i, best_j = i, j
        return max_eval, (best_i, best_j)
    else:
        min_eval = float('inf')
        for i in range(8):
            for j in range(8):
                if game.is_valid_move(i, j):
                    game_copy = game.copy()
                    game_copy.make_move(i, j)
                    eval, _ = minimax(game_copy, depth - 1, True)
                    if eval < min_eval:
                        min_eval = eval
                        best_i, best_j = i, j
        return min_eval, (best_i, best_j)
    
def get_depth(game, move_count):
    if (type(game) == OthelloGame):
        return min(move_count // 5 + 1, 6)
