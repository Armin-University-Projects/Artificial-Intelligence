import numpy as np

def calculate(data):
    ps = np.bincount(data) / len(data)
    entropy = -np.sum([p * np.log2(p) for p in ps if p > 0])
    return entropy