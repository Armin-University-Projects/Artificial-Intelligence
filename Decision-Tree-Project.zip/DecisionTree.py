import numpy as np
from Node import Node
import gini_index
import calculations as cl

class DecisionTree:
    def __init__(self, min_split_samples=2, max_depth=100, features_count=None, impurity_function=gini_index.calculate):
        self.min_split_samples = min_split_samples
        self.max_depth = max_depth
        self.features_count = features_count
        self.root = None
        self.impurity_function = impurity_function

    def fit(self, data, target):
        self.features_count = data.shape[1] if not self.features_count else min(data.shape[1], self.features_count)
        self.root = self.__make_tree(data, target)

    def __make_tree(self, data, target, current_depth=0):
        samples_count, features_count = data.shape
        labels_count = len(np.unique(target))

        if current_depth >= self.max_depth or labels_count == 1 or samples_count < self.min_split_samples:
            return Node(value=cl.most_common_label(target))

        feat_idxs = np.random.choice(features_count, self.features_count, replace=False)

        best_feature, best_threshold = cl.best_split(data, target, feat_idxs, self.impurity_function)

        left, right = cl.make_split(data[:, best_feature], best_threshold)
        
        left = self.__make_tree(data[left, :], target[left], current_depth + 1)
        right = self.__make_tree(data[right, :], target[right], current_depth + 1)
        return Node(best_feature, best_threshold, left, right)

    def predict(self, data):
        return np.array([self.traverse_tree(dataset, self.root) for dataset in data])

    def traverse_tree(self, data, node):
        if node.is_leaf_node():
            return node.value
        return self.traverse_tree(data, node.left if data[node.feature] <= node.threshold else node.right)
    
    def print_tree(self, node:Node):
        print(f'feature: {node.feature}, threshold: {node.threshold}, value: {node.value}')
        print('left-> ', end="\t")
        if node.left != None:
            print(f'feature: {node.left.feature}, threshold: {node.left.threshold}, value: {node.left.value}')
            
        print('right-> ', end="\t")
        if node.right != None:
            print(f'feature: {node.right.feature}, threshold: {node.right.threshold}, value: {node.right.value}')
        
        print('\n')
        
        if node.left != None:
            self.print_tree(node.left)
        if node.right != None:
            self.print_tree(node.right)
