import numpy as np

def calculate(data):
    p = np.bincount(data) / len(data)
    gini = 1 - np.sum(p ** 2)
    return gini
