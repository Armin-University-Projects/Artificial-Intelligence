from collections import Counter
import numpy as np

def most_common_label(dataset):
    counter = Counter(dataset)
    return counter.most_common(1)[0][0]

def information_gain(target, column, threshold, impurity_function):
        left, right = make_split(column, threshold)

        if len(left) == 0 or len(right) == 0:
            return 0

        count = len(target)
        left_count, right_count = len(left), len(right)
        left_impurity, right_impurity = impurity_function(target[left]), impurity_function(target[right])
        average_impurity = (left_count / count) * left_impurity + (right_count / count) * right_impurity

        main_impurity = impurity_function(target)
        return main_impurity - average_impurity
    
def best_split(data, target, feature_indexes, impurity_function):
        max_information_gain = -1
        split_index, split_threshold = None, None

        for index in feature_indexes:
            column = data[:, index]
            thresholds = np.unique(column)

            for thr in thresholds:
                gain = information_gain(target, column, thr, impurity_function)

                if gain > max_information_gain:
                    max_information_gain = gain
                    split_index = index
                    split_threshold = thr

        return split_index, split_threshold
    
def make_split(column, split_thresh):
        left = np.argwhere(column <= split_thresh).flatten()
        right = np.argwhere(column > split_thresh).flatten()
        return left, right
    
def accuracy(test, prediction):
    return np.sum(test == prediction) / len(test)
